<?php

namespace App\Intranet\Utils;



class Path {

    
    CONST ROOT =  __DIR__ . '/../../../../';

    



}